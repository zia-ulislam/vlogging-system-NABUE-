// routes/index.js

const express = require('express');
const router = express.Router();
const Post = require('nabue\models\Post.js');

// Home Page - List all posts
router.get('/', async (req, res) => {
    try {
        const posts = await Post.find().populate('author');
        res.render('home', { title: 'Home - NABUE', posts });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

module.exports = router;
