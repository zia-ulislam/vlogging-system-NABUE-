// routes/auth.js

const express = require('express');
const router = express.Router();
const User = require('../models/User');
const passport = require('passport');
const { body, validationResult } = require('express-validator');

// Login Page
router.get('/login', (req, res) => {
    res.render('login', { title: 'Login' });
});

// Login Handle
router.post('/login', passport.authenticate('local', {
    successRedirect: '/',
    failureRedirect: '/auth/login',
    failureFlash: true
}));

// Signup Page
router.get('/signup', (req, res) => {
    res.render('signup', { title: 'Signup' });
});

// Signup Handle
router.post('/signup', [
    body('username').notEmpty().withMessage('Username is required'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters')
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.render('signup', { title: 'Signup', errors: errors.array() });
    }

    const { username, password } = req.body;

    try {
        const user = new User({ username, password });
        await user.save();
        req.flash('success_msg', 'You are now registered and can log in');
        res.redirect('/auth/login');
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Error registering user');
        res.redirect('/auth/signup');
    }
});

// Logout Handle
router.get('/logout', (req, res) => {
    req.logout();
    req.flash('success_msg', 'You are logged out');
    res.redirect('/');
});

module.exports = router;
