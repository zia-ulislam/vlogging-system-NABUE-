// routes/posts.js

const express = require('express');
const router = express.Router();
const Post = require('nabue\models\Post.js');
const { ensureAuthenticated } = require('../middleware/auth');

// Create New Post - Show form
router.get('/create', ensureAuthenticated, (req, res) => {
    res.render('post', { title: 'Create New Post' });
});

// Create New Post - Handle form submission
router.post('/create', ensureAuthenticated, async (req, res) => {
    const { title, content, image } = req.body;
    try {
        const newPost = new Post({
            title,
            content,
            image,
            author: req.user._id
        });
        await newPost.save();
        req.flash('success_msg', 'Post created successfully');
        res.redirect('/');
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Error creating post');
        res.redirect('/posts/create');
    }
});

// View Single Post
router.get('/:id', async (req, res) => {
    try {
        const post = await Post.findById(req.params.id).populate('author');
        if (!post) {
            return res.status(404).send('Post not found');
        }
        res.render('post', { title: post.title, post });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// Edit Post - Show form
router.get('/:id/edit', ensureAuthenticated, async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);
        if (!post || post.author.toString() !== req.user._id.toString()) {
            return res.redirect('/');
        }
        res.render('post', { title: 'Edit Post', post });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// Edit Post - Handle form submission
router.post('/:id/edit', ensureAuthenticated, async (req, res) => {
    const { title, content, image } = req.body;
    try {
        const post = await Post.findById(req.params.id);
        if (!post || post.author.toString() !== req.user._id.toString()) {
            return res.redirect('/');
        }
        post.title = title;
        post.content = content;
        post.image = image;
        await post.save();
        req.flash('success_msg', 'Post updated successfully');
        res.redirect(`/posts/${post._id}`);
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Error updating post');
        res.redirect(`/posts/${req.params.id}/edit`);
    }
});

// Delete Post
router.post('/:id/delete', ensureAuthenticated, async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);
        if (!post || post.author.toString() !== req.user._id.toString()) {
            return res.redirect('/');
        }
        await Post.findByIdAndRemove(req.params.id);
        req.flash('success_msg', 'Post deleted successfully');
        res.redirect('/');
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Error deleting post');
        res.redirect(`/posts/${req.params.id}`);
    }
});

module.exports = router;
