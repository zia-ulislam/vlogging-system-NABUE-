// scripts.js

document.addEventListener('DOMContentLoaded', function () {
    // Example: Alert on button click
    document.querySelectorAll('.post-card button').forEach(button => {
        button.addEventListener('click', function () {
            alert('Button clicked!');
        });
    });

    // Example: Handle form submission
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function (e) {
            // Perform any client-side validation or manipulation here
            console.log('Form submitted!');
        });
    });
});
